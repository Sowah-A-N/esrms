ESRMS - End-of-Semester Results Management System (Vanilla PHP + MySQLi)

Setup Instructions:
1. Copy the 'esrms' folder into your webroot (e.g., C:\xampp\htdocs\ or /var/www/html/).
2. Create MySQL database 'esrms_db' and import the provided SQL schema (esrms_schema.sql).
3. Update config/db_connect.php if your MySQL credentials differ.
4. Ensure the 'uploads/files' directory is writable by the web server.
5. Access the app at http://localhost/esrms/auth/login.php

Default DB Credentials in SQL file:
- User: admin
- Password: 'password' (see below how to set)

Notes:
- Session handling uses the database. Make sure sessions table exists.
- Upload folder is protected by .htaccess; PHP download endpoint serves files.
- You can change user roles in the 'users' table (admin, hod, secretary).
