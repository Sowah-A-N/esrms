<?php
include('../includes/auth_guard.php');
require_role(array('admin','hod'));
include('../config/db_connect.php');
include('../includes/header.php');

$res = mysqli_query($conn, "SELECT al.*, u.username FROM activity_log al LEFT JOIN users u ON al.user_id = u.user_id ORDER BY al.action_time DESC LIMIT 200");
?>
<h2>Activity Logs</h2>
<table border="1" cellpadding="5">
<tr><th>User</th><th>Action</th><th>Upload ID</th><th>IP</th><th>Time</th></tr>
<?php while($row = mysqli_fetch_assoc($res)): ?>
<tr>
<td><?php echo htmlspecialchars($row['username']); ?></td>
<td><?php echo htmlspecialchars($row['action_type']); ?></td>
<td><?php echo htmlspecialchars($row['upload_id']); ?></td>
<td><?php echo htmlspecialchars($row['ip_address']); ?></td>
<td><?php echo htmlspecialchars($row['action_time']); ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php include('../includes/footer.php'); ?>