<?php
include('includes/auth_guard.php');
include('includes/header.php');
?>
<h2>ESRMS Dashboard</h2>
<p>Welcome, user ID: <?php echo htmlspecialchars($_SESSION['user_id']); ?>. Use the menu to navigate.</p>
<?php include('includes/footer.php'); ?>