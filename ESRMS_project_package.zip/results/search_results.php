<?php
include('../includes/auth_guard.php');
include('../config/db_connect.php');

$search = '';
$results = null;
if (isset($_GET['q'])) {
    $search = mysqli_real_escape_string($conn, $_GET['q']);
    $sql = "SELECT * FROM uploads WHERE course_code LIKE '%$search%' OR course_title LIKE '%$search%' OR lecturer_name LIKE '%$search%' OR session LIKE '%$search%'";
    $results = mysqli_query($conn, $sql);
}
include('../includes/header.php');
?>
<h2>Search Form A Records</h2>
<form method="GET">
    <input type="text" name="q" placeholder="Search by course, lecturer, or session" value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit">Search</button>
</form>

<?php if($results): ?>
<table border="1" cellpadding="5">
<tr><th>Course Code</th><th>Title</th><th>Lecturer</th><th>Semester</th><th>Session</th><th>Action</th></tr>
<?php while($row = mysqli_fetch_assoc($results)): ?>
<tr>
<td><?php echo htmlspecialchars($row['course_code']); ?></td>
<td><?php echo htmlspecialchars($row['course_title']); ?></td>
<td><?php echo htmlspecialchars($row['lecturer_name']); ?></td>
<td><?php echo htmlspecialchars($row['semester']); ?></td>
<td><?php echo htmlspecialchars($row['session']); ?></td>
<td><a href="download.php?id=<?php echo intval($row['upload_id']); ?>">Download</a></td>
</tr>
<?php endwhile; ?>
</table>
<?php endif; ?>

<?php include('../includes/footer.php'); ?>