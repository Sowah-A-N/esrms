<?php
include('../includes/auth_guard.php');
include('../config/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_code = mysqli_real_escape_string($conn, $_POST['course_code']);
    $course_title = mysqli_real_escape_string($conn, $_POST['course_title']);
    $lecturer = mysqli_real_escape_string($conn, $_POST['lecturer_name']);
    $semester = $_POST['semester'];
    $session = mysqli_real_escape_string($conn, $_POST['session']);
    $dept = mysqli_real_escape_string($conn, $_SESSION['department_code']);
    $uploaded_by = intval($_SESSION['user_id']);

    $file = $_FILES['form_file'];
    $target_dir = __DIR__ . "/files/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    $file_name = basename($file['name']);
    $unique = time() . "_" . preg_replace('/[^A-Za-z0-9_\.\-]/', '_', $file_name);
    $target_file = $target_dir . $unique;
    $file_type = strtoupper(pathinfo($file_name, PATHINFO_EXTENSION));

    $allowed = array('PDF','XLS','XLSX');
    if (!in_array($file_type, $allowed)) {
        echo "Invalid file type.";
        exit();
    }

    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        $file_path_db = 'uploads/files/' . $unique;
        $sql = "INSERT INTO uploads (course_code, course_title, lecturer_name, department_code, semester, session, file_name, file_path, file_type, uploaded_by)
                VALUES ('$course_code', '$course_title', '$lecturer', '$dept', '$semester', '$session', '$file_name', '$file_path_db', '$file_type', $uploaded_by)";
        mysqli_query($conn, $sql);

        $log = "INSERT INTO activity_log (user_id, action_type, upload_id, ip_address)
                VALUES ($uploaded_by, 'UPLOAD', NULL, '{$_SERVER['REMOTE_ADDR']}')";
        mysqli_query($conn, $log);

        echo "<p>File uploaded successfully.</p><a href='upload_form.php'>Upload another</a>";
    } else {
        echo "<p style='color:red;'>Upload failed.</p>";
    }
}
?>