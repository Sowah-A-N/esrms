<?php
// set_admin_password.php
// Usage: place this file into your ESRMS project root (where config/db_connect.php exists) and run it from the browser or CLI.
// It will prompt (via simple HTML form) for a new admin password, hash it with password_hash(), and update the 'admin' user record.
//
// WARNING: delete this file after use for security.

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include('config/db_connect.php'); // ensure this path matches your deployment
    $newpass = $_POST['newpass'] ?? '';
    if (empty($newpass)) {
        echo "Password cannot be empty.";
        exit;
    }
    $hash = password_hash($newpass, PASSWORD_DEFAULT);
    $sql = "UPDATE users SET password_hash = '" . mysqli_real_escape_string($conn, $hash) . "' WHERE username = 'admin' LIMIT 1";
    if (mysqli_query($conn, $sql)) {
        echo "<p>Admin password updated successfully. Delete this file now for security.</p>";
    } else {
        echo "<p>DB error: " . mysqli_error($conn) . "</p>";
    }
    exit;
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Set Admin Password</title></head>
<body>
<h2>Set Admin Password</h2>
<form method="POST">
<label>New password:</label><input type="password" name="newpass" required>
<button type="submit">Set Password</button>
</form>
<p>After successful update, delete this file.</p>
</body>
</html>
